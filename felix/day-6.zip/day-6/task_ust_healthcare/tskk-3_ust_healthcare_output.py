# Create outputs for ust healthcare

import csv
    
# opening patient data file
with open("ust_healthcare_visits.csv","r") as file:
    reader = csv.DictReader(file)
    # storing of headers
    header = reader.fieldnames
    with open("pending_payments.csv","w",newline="") as file1:
        writer = csv.DictWriter(file1,header)
        writer.writeheader()
        for row in reader:
            if row['payment_status'].title() != 'Paid':
                writer.writerow(row)
                
# patient summery


with open("ust_healthcare_visits.csv","r") as file:
    reader = csv.DictReader(file)
    d={}
    for row in reader:
        if row["payment_status"] != 'paid':
            payment = 'Yes'
        else:
            payment = 'No'
        # print(row['patient_id'])
        if row['patient_id'] in d:
            d[row['patient_id']][1] += 1
            d[row['patient_id']][2] += row['billed_amount']
            d[row['patient_id']][3] = payment
        else:
            d[row['patient_id']] = [row['name'],1,row['billed_amount'],payment]
        # d[row['patient_id']] = [d.get(d[row['patient_id']][1],0)+1,d.get(d[row['patient_id']][2],0)+row['billed_amount'],payment]

with open("patient_summary.csv","w",newline='') as file:
    writer = csv.writer(file)
    main_list = []
    for i in d:
        list = []
        list.append(i)
        list.extend(d[i])
        main_list.append(list)
    writer.writerows(main_list)