# ust healthcare

import csv
skipped_rows = 0
processed_rows = 0
with open("ust_healthcare_visit.csv","r") as file:
    
    reader = csv.DictReader(file)
    next(reader)
    
    for row in reader:
        # checking if any important fields are missing
        if 'patient_id' not in row or 'name' not in row or 'visit_date' not in row or 'billed_amount' not in row or 'payment_status' not in row:
            print("Field is missing")
            skipped_rows += 1
            continue
        else:
            processed_rows += 1
            print(row['patient_id'],row['name'],row['visit_date'],row['billed_amount'],row['payment_status'])

with open("ust_healthcare_visit.csv","r") as file:
    reader1 = csv.DictReader(file)
    next(reader1)
    for row in reader1:
    # chechking that if the bill amount if convertable to float
        if float(row['billed_amount']):
            row['billed_amount'] = float(row['billed_amount'])
        else:
            print("Can't convert it into float")
            skipped_rows += 1
            continue
        
        # Triming whitespace
        for key in row:
            if type(row[key]) == str:
                row[key] = row[key].strip()

        
        # Normalise payment status to title case
        row['payment_status'] = row['payment_status'].capitalize()
        
        # Normalise followups
        if not row['follow_up_required']:
            row['follow_up_required'] = "No"
            
        processed_rows += 1
        
        print(row)
        
print("Skipped rows: ",skipped_rows)
print("Processed rows: ",processed_rows)

        
    