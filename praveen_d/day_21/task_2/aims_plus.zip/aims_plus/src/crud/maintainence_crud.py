# src/crud/maintenance_crud.py
import pymysql
from typing import List, Optional
from models.maintenance_model import MaintenanceLog  # Pydantic model for Maintenance
from config.db_connection import get_connection

# Database connection function
# 1. Create a new maintenance record
def create_maintenance(maintenance: MaintenanceLog):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
    INSERT INTO aims_db.maintenance_log (maintenance_code, equipment_id, description, maintenance_date, status)
    VALUES (%s, %s, %s, %s, %s)
    """
    data = (maintenance.maintenance_code, maintenance.equipment_id, maintenance.description,
            maintenance.maintenance_date, maintenance.status)
    cursor.execute(query, data)
    conn.commit()
    cursor.close()
    conn.close()

# 2. Get all maintenance records
def get_all_maintenance() -> List[MaintenanceLog]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM aims_db.maintenance_log"
    cursor.execute(query)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return [MaintenanceLog(**row) for row in rows]  # Convert rows to list of Maintenance objects

# 3. Get maintenance records by status
def get_maintenance_by_status(status: str) -> List[MaintenanceLog]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM aims_db.maintenance_log WHERE status = %s"
    cursor.execute(query, (status,))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return [MaintenanceLog(**row) for row in rows]

# 4. Get a maintenance record by ID
def get_maintenance_by_id(id: int) -> Optional[MaintenanceLog]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM aims_db.maintenance_log WHERE maintenance_id = %s"
    cursor.execute(query, (id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    if row:
        return MaintenanceLog(**row)
    return None

# 5. Update a maintenance record by ID
def update_maintenance(id: int, maintenance: dict):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
    UPDATE aims_db.maintenance_log SET maintenance_code = %s, equipment_id = %s, description = %s, 
    maintenance_date = %s, status = %s WHERE maintenance_id = %s
    """
    data = (maintenance["maintenance_code"], maintenance["equipment_id"], maintenance["description"],
            maintenance["maintenance_date"], maintenance["status"], id)
    cursor.execute(query, data)
    conn.commit()
    cursor.close()
    conn.close()

# 6. Update maintenance status by ID
def update_maintenance_status(id: int, status: str):
    conn = get_connection()
    cursor = conn.cursor()
    query = "UPDATE aims_db.maintenance_log SET status = %s WHERE maintenance_id = %s"
    cursor.execute(query, (status, id))
    conn.commit()
    cursor.close()
    conn.close()

# 7. Delete a maintenance record by ID
def delete_maintenance(id: int):
    conn = get_connection()
    cursor = conn.cursor()
    query = "DELETE FROM aims_db.maintenance_log WHERE maintenance_id = %s"
    cursor.execute(query, (id,))
    conn.commit()
    cursor.close()
    conn.close()

# 8. Search maintenance records by keyword
def search_maintenance_by_keyword(keyword: str) -> List[MaintenanceLog]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM aims_db.maintenance_log WHERE maintenance_code LIKE %s OR description LIKE %s"
    like_keyword = f"%{keyword}%"
    cursor.execute(query, (like_keyword, like_keyword))
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return [MaintenanceLog(**row) for row in rows]

# 9. Get count of maintenance records
def get_maintenance_count() -> int:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT COUNT(*) FROM aims_db.maintenance_log"
    cursor.execute(query)
    count = cursor.fetchone()[0]
    cursor.close()
    conn.close()
    return count
