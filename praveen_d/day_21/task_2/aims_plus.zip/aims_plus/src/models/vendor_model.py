import csv
import re
from datetime import datetime
from pydantic import BaseModel, field_validator, ValidationError
import os

# Define custom exceptions
class ValidationErrorException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

# Predefined valid values
valid_active_statuses = ['Active', 'Inactive']
valid_cities = ['Bangalore', 'Kolkata', 'Chennai', 'Mumbai', 'Hyderabad', 'Delhi']

# Pydantic Model for Vendor
class Vendor(BaseModel):
    vendor_id: str
    vendor_name: str
    contact_person: str
    contact_phone: str
    gst_number: str
    email: str
    address: str
    city: str
    active_status: str

    # Field Validators for each field

    @field_validator('vendor_id')
    def validate_vendor_id(cls, v):
        vendor_ids = getattr(cls, 'vendor_ids', set())  # Use a class-level variable to track vendor_ids
        if v in vendor_ids:
            raise ValueError(f"Duplicate vendor_id: {v}")
        vendor_ids.add(v)
        cls.vendor_ids = vendor_ids  # Store the updated set of vendor_ids
        return v

    @field_validator('vendor_name')
    def validate_vendor_name(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Vendor name cannot be empty")
        if not re.match(r"^[A-Za-z\s]+$", v):
            raise ValueError(f"Invalid vendor_name: {v}")
        return v

    @field_validator('contact_person')
    def validate_contact_person(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Contact person cannot be empty")
        if not re.match(r"^[A-Za-z\s]+$", v):
            raise ValueError(f"Invalid contact_person: {v}")
        return v

    @field_validator('contact_phone')
    def validate_contact_phone(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Contact phone cannot be empty")
        v = str(v)
        if not re.match(r"^[6-9]\d{9}$", v):
            raise ValueError(f"Invalid contact_phone: {v}")
        return v

    @field_validator('gst_number')
    def validate_gst_number(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("GST number cannot be empty")
        pattern = r"^[A-Z0-9]{15}$"
        if not re.match(pattern, v):
            raise ValueError(f"Invalid gst_number: {v}")
        return v

    @field_validator('email')
    def validate_email(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Email cannot be empty")
        if not re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", v):
            raise ValueError(f"Invalid email: {v}")
        return v

    @field_validator('address')
    def validate_address(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Address cannot be empty")
        return v

    @field_validator('city')
    def validate_city(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("City cannot be empty")
        if v not in valid_cities:
            raise ValueError(f"Invalid city: {v}")
        return v

    @field_validator('active_status')
    def validate_active_status(cls, v):
        if v is None or v.strip() == "":
            raise ValueError("Active status cannot be empty")
        if v not in valid_active_statuses:
            raise ValueError(f"Invalid active_status: {v}")
        return v


# Function to validate a row in the CSV
def validate_vendor(row, vendor_ids):
    try:
        # Create Pydantic model instance to validate the row
        Vendor(**row)
        return None  # All validations passed
    except ValidationError as e:
        raise ValidationErrorException(f"Validation failed: {e.errors()}")


# Function to validate the entire CSV and write valid rows to a new file
def validate_csv(csv_path, output_file_path):
    vendor_ids = set()  # Set to track unique vendor_ids
    errors = []
    valid_vendor_list = []  # List to store valid rows

    try:
        with open(csv_path, mode='r') as file:
            reader = csv.DictReader(file)
            header = reader.fieldnames

            # Process each row in the CSV
            for index, row in enumerate(reader, start=1):
                try:
                    # Validate each vendor row using the functions
                    validate_vendor(row, vendor_ids)
                    valid_vendor_list.append(row)  # If validation passes, add to valid list
                except ValidationErrorException as e:
                    # Errors are handled here, but not saved in a separate file
                    # print(f"Row {index}: {e.message}")
                    pass

        # Output file path for writing the valid vendor rows
        output_file = os.path.join(output_file_path, "valid_vendor.csv")

        # Write the valid rows to a new CSV file
        with open(output_file, mode='w', newline='') as output_file:
            writer = csv.DictWriter(output_file, fieldnames=header)
            writer.writeheader()
            writer.writerows(valid_vendor_list)  # Write valid rows

        # Return the result based on the validation
        if valid_vendor_list:
            return f"No errors found. {len(valid_vendor_list)} rows were validated successfully."
        else:
            return "No valid data found."

    except Exception as e:
        return f"An error occurred: {str(e)}"


# Example usage
csv_path_vendor = 'C:\\UST PYTHON\\Praveen\\ust_python_training\\praveen_d\\day_18\\task_2\\aims_plus\\database\\sample_data\\vendor_master.csv'
output_file_path_vendor = r'C:\UST PYTHON\Praveen\ust_python_training\praveen_d\day_18\task_2\aims_plus\database\output_data'

# Run the validation
validation_result = validate_csv(csv_path_vendor, output_file_path_vendor)
# print(validation_result)
