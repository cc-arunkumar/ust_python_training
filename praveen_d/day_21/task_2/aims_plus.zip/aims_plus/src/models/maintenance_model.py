import csv
import re
from datetime import datetime
from pydantic import BaseModel, field_validator, ValidationError
import os

# Define custom exceptions
class ValidationErrorException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

# Predefined valid values
valid_maintenance_types = ['Repair', 'Service', 'Upgrade']
valid_statuses = ['Completed', 'Pending']

# Pydantic Model for Maintenance Log
class MaintenanceLog(BaseModel):
    log_id: str
    asset_tag: str
    maintenance_type: str
    vendor_name: str
    description: str
    cost: float
    maintenance_date: str
    technician_name: str
    status: str

    # Field Validators for each field

    @field_validator('log_id')
    def validate_log_id(cls, v):
        log_ids = getattr(cls, 'log_ids', set())  # Use a class-level variable to track log_ids
        if v in log_ids:
            raise ValueError(f"Duplicate log_id: {v}")
        log_ids.add(v)
        cls.log_ids = log_ids  # Store the updated set of log_ids
        return v

    @field_validator('asset_tag')
    def validate_asset_tag(cls, v):
        if v is None or not v.startswith('UST-'):
            raise ValueError(f"Invalid asset_tag: {v}")
        return v

    @field_validator('maintenance_type')
    def validate_maintenance_type(cls, v):
        if v not in valid_maintenance_types:
            raise ValueError(f"Invalid maintenance_type: {v}")
        return v

    @field_validator('vendor_name')
    def validate_vendor_name(cls, v):
        if not v.isalpha() and ' ' not in v:
            raise ValueError(f"Invalid vendor_name: {v}")
        return v

    @field_validator('description')
    def validate_description(cls, v):
        if len(v) < 10:
            raise ValueError(f"Description is too short: {v}")
        return v

    @field_validator('cost')
    def validate_cost(cls, v):
        if v <= 0:
            raise ValueError(f"Invalid cost: {v}")
        return v

    @field_validator('maintenance_date')
    def validate_maintenance_date(cls, v):
        date_pattern = r"^\d{4}-\d{2}-\d{2}$"
        if not re.match(date_pattern, v):
            raise ValueError(f"Invalid date format for maintenance_date: {v}")
        try:
            maintenance_date_obj = datetime.strptime(v, '%Y-%m-%d')
            if maintenance_date_obj > datetime.today():
                raise ValueError(f"Invalid maintenance_date (future date): {v}")
        except ValueError:
            raise ValueError(f"Invalid date format for maintenance_date: {v}")
        return v

    @field_validator('technician_name')
    def validate_technician_name(cls, v):
        if not v.isalpha() and ' ' not in v:
            raise ValueError(f"Invalid technician_name: {v}")
        return v

    @field_validator('status')
    def validate_status(cls, v):
        if v not in valid_statuses:
            raise ValueError(f"Invalid status: {v}")
        return v


# Function to validate a row in the CSV
def validate_maintenance(row, log_ids):
    try:
        # Create Pydantic model instance to validate the row
        MaintenanceLog(**row)
        return None  # All validations passed
    except ValidationError as e:
        raise ValidationErrorException(f"Validation failed: {e.errors()}")


# Function to validate the entire CSV and write valid rows to a new file
def validate_csv(csv_path, output_file_path):
    log_ids = set()  # Set to track unique log_ids
    valid_maintenance = []

    try:
        with open(csv_path, mode='r') as file:
            reader = csv.DictReader(file)
            header = reader.fieldnames

            # Process each row in the CSV
            for index, row in enumerate(reader, start=1):
                try:
                    # Validate each maintenance row using the functions
                    validate_maintenance(row, log_ids)
                    valid_maintenance.append(row)  # If validation passes, add to valid list
                except ValidationErrorException as e:
                    # Errors are handled here, but not saved in a separate file
                    pass
                    # print(f"Row {index}: {e.message}")

        # Output file path for writing the valid maintenance rows
        output_file = os.path.join(output_file_path, "valid_maintenance.csv")

        # Write the valid rows to a new CSV file
        with open(output_file, mode='w', newline='') as output_file:
            writer = csv.DictWriter(output_file, fieldnames=header)
            writer.writeheader()
            writer.writerows(valid_maintenance)  # Write valid rows

        # Return the result based on the validation
        if valid_maintenance:
            return f"All data is valid. {len(valid_maintenance)} rows validated successfully."
        else:
            return "No valid data found."

    except Exception as e:
        return f"An error occurred: {str(e)}"


# Example usage
csv_path_maintenance = 'C:\\UST PYTHON\\Praveen\\ust_python_training\\praveen_d\\day_18\\task_2\\aims_plus\\database\\sample_data\\maintenance_log.csv'
output_file_path_maintenance = r'C:\UST PYTHON\Praveen\ust_python_training\praveen_d\day_18\task_2\aims_plus\database\output_data'

# Run the validation
validation_result = validate_csv(csv_path_maintenance, output_file_path_maintenance)
# print(validation_result)
