from pydantic import BaseModel, field_validator, ValidationError, model_validator
from datetime import datetime
from typing import Optional
import re
import csv
import os

# Define custom exceptions (kept for your use)
class ValidationErrorException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

# Predefined valid values
valid_departments = ['HR', 'IT', 'Admin', 'Finance']
valid_locations = ['Bangalore', 'Kolkata', 'Chennai', 'Mumbai', 'Hyderabad', 'Delhi']
valid_statuses = ['Active', 'Inactive', 'Resigned']

class Employee(BaseModel):
    emp_code: str
    full_name: str
    email: str
    phone: str
    department: str
    location: str
    join_date: str
    status: str

    # Field Validators
    @field_validator('emp_code')
    def validate_emp_code(cls, v):
        if not v.startswith('USTEMP-'):
            raise ValueError(f"Invalid emp_code: {v}")
        return v

    @field_validator('full_name')
    def validate_full_name(cls, v):
        if not re.match(r"^[A-Za-z\s]+$", v):
            raise ValueError(f"Invalid full_name: {v}")
        return v

    @field_validator('email')
    def validate_email(cls, v):
        if not v.endswith('@ust.com'):
            raise ValueError(f"Invalid email: {v}")
        return v

    @field_validator('phone')
    def validate_phone(cls, v):
        if not re.match(r"^[6-9]\d{9}$", str(v)):
            raise ValueError(f"Invalid phone: {v}")
        return v

    @field_validator('department')
    def validate_department(cls, v):
        if v not in valid_departments:
            raise ValueError(f"Invalid department: {v}")
        return v

    @field_validator('location')
    def validate_location(cls, v):
        if v not in valid_locations:
            raise ValueError(f"Invalid location: {v}")
        return v

    @field_validator('join_date')
    def validate_join_date(cls, v):
        try:
            join_date_obj = datetime.strptime(v, "%Y-%m-%d")
            if join_date_obj > datetime.today():
                raise ValueError(f"Invalid join_date: {v}")
        except ValueError:
            raise ValueError(f"Invalid date format for join_date: {v}")
        return v

    @field_validator('status')
    def validate_status(cls, v):
        if v not in valid_statuses:
            raise ValueError(f"Invalid status: {v}")
        return v

    # Optional root_validator to check all fields at once if needed
    @model_validator(mode="after")
    def check_all_fields(cls, values):
        # You can add any cross-field validation logic here if needed.
        return values

# Function to validate each row in employee directory
def validate_employee(row):
    try:
        # Create Employee model instance to validate the row
        Employee(**row)
        return None  # All validations passed
    except ValidationError as e:
        raise ValidationErrorException(f"Validation failed for row: {e.errors()}")

# Function to validate the entire CSV and write errors to a new file
def validate_csv(csv_path, output_file_path):
    errors = []
    valid_employee_list = []  # List to store valid rows
    try:
        with open(csv_path, mode='r') as file:
            reader = csv.DictReader(file)
            header = reader.fieldnames

            # Process each row in the CSV
            for index, row in enumerate(reader, start=1):
                try:
                    validate_employee(row)
                    valid_employee_list.append(row)
                except ValidationErrorException as e:
                    errors.append(f"Row {index}: {e.message}")

        # Ensure the output directory exists, if not, create it
        if not os.path.exists(output_file_path):
            os.makedirs(output_file_path)

        # Output file path for writing the valid employee rows
        output_file = os.path.join(output_file_path, "valid_employee.csv")

        # Write the valid rows to a new CSV file
        with open(output_file, mode='w', newline='') as output_file:
            writer = csv.DictWriter(output_file, fieldnames=header)
            writer.writeheader()
            writer.writerows(valid_employee_list)  # Write valid rows

        # Print the result based on the validation
        if errors:
            return f"Validation completed with errors. Errors are written to {output_file_path}."
        else:
            return f"No errors found. {len(valid_employee_list)} rows were validated successfully."

    except Exception as e:
        return f"An error occurred: {str(e)}"

# Example usage
csv_path_employee = r"C:\UST PYTHON\Praveen\ust_python_training\praveen_d\day_18\task_2\aims_plus\database\sample_data\employee_directory.csv"
output_file_path_employee = r'C:\UST PYTHON\Praveen\ust_python_training\praveen_d\day_18\task_2\aims_plus\database\output_data'

validation_result = validate_csv(csv_path_employee, output_file_path_employee)
# print(validation_result)
